function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var NavTabInfo = function NavTabInfo(label, route) {
  _classCallCheck(this, NavTabInfo);

  this.label = label;
  this.route = route;
};

export { NavTabInfo as default };